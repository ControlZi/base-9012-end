export default new WeakMap
